import { Star, Video, Target, Languages, DollarSign } from 'lucide-react';

const reasons = [
  {
    icon: Star,
    text: '200+ trending & tested products'
  },
  {
    icon: Video,
    text: 'Complete practical guidance (video / screen-share support)'
  },
  {
    icon: Target,
    text: 'Initial orders strategy for new seller account'
  },
  {
    icon: Languages,
    text: 'Simple language, Hindi + English support'
  },
  {
    icon: DollarSign,
    text: 'Minimum service charges'
  }
];

export default function WhyUs() {
  return (
    <section className="py-16 md:py-20 bg-gradient-to-br from-purple-900 to-purple-800 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utb3BhY2l0eT0iLjA1IiBzdHJva2Utd2lkdGg9IjIiLz48L2c+PC9zdmc+')] opacity-10"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Why Work With Fortunemakers
          </h2>
          <p className="text-xl text-purple-200">Your trusted partner for Meesho success</p>
        </div>

        <div className="max-w-4xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all border border-white/20"
              >
                <div className="bg-yellow-400 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-purple-900" />
                </div>
                <p className="text-lg font-medium leading-relaxed">
                  {reason.text}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
