import { UserCheck, ShoppingBag, TrendingUp, Package } from 'lucide-react';

const services = [
  {
    icon: UserCheck,
    title: 'Meesho Seller Account Opening',
    description: 'Fully verified professional Meesho seller account setup – mobile, email, GST, bank account linking, pickup address etc.',
    color: 'bg-purple-100 text-purple-900'
  },
  {
    icon: ShoppingBag,
    title: 'Trending Product Listing',
    description: '200+ trending catalog se top products choose करके professionally listing करते हैं – title, description, images, price optimisation.',
    color: 'bg-yellow-100 text-yellow-900'
  },
  {
    icon: TrendingUp,
    title: 'Order Optimization Process',
    description: 'Fast orders लाने की strategy, store ranking improve करने की guidance, सही pricing & offer planning.',
    color: 'bg-purple-100 text-purple-900'
  },
  {
    icon: Package,
    title: 'Product Packing to Dispatch – Complete Guide',
    description: '',
    points: [
      'Label download & printing help',
      'Product packing step-by-step',
      'Packaging material guidance',
      'Dispatch process on Meesho panel',
      'Delivery boy को parcel handover कैसे करें',
      'RTO कम करने की techniques'
    ],
    color: 'bg-yellow-100 text-yellow-900'
  }
];

export default function Services() {
  return (
    <section className="py-16 md:py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-purple-900 mb-4">
            Our Services – A to Z Full Support
          </h2>
          <p className="text-lg text-gray-600">Complete guidance for your Meesho business journey</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl p-6 md:p-8 shadow-md hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className={`${service.color} w-14 h-14 rounded-lg flex items-center justify-center mb-5`}>
                  <Icon className="w-7 h-7" />
                </div>

                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-3">
                  {service.title}
                </h3>

                {service.description && (
                  <p className="text-gray-700 leading-relaxed">
                    {service.description}
                  </p>
                )}

                {service.points && (
                  <ul className="space-y-2 mt-3">
                    {service.points.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-gray-700">
                        <span className="text-yellow-500 mt-1">•</span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
