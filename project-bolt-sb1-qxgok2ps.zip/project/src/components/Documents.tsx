import { FileText, CheckCircle } from 'lucide-react';

const documents = [
  'Mobile Number',
  'Email ID',
  'GST Number',
  'Bank Account Details (Current/Saving)',
  'Aadhaar Card',
  'PAN Card'
];

export default function Documents() {
  return (
    <section className="py-16 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mb-4">
              <FileText className="w-8 h-8 text-purple-900" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-purple-900 mb-3">
              Documents Required
            </h2>
            <p className="text-lg text-gray-600">For New Meesho Seller Account</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-white rounded-2xl p-8 md:p-10 shadow-lg border border-purple-100">
            <ul className="grid sm:grid-cols-2 gap-4">
              {documents.map((doc, index) => (
                <li key={index} className="flex items-center gap-3 text-gray-800">
                  <CheckCircle className="w-6 h-6 text-yellow-500 flex-shrink-0" />
                  <span className="text-lg font-medium">{doc}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
