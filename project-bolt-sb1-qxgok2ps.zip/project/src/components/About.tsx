export default function About() {
  return (
    <section className="py-16 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-purple-900 mb-6">
            About Fortunemakers
          </h2>
          <p className="text-lg md:text-xl text-gray-700 leading-relaxed">
            Fortunemakers एक E-Commerce Company है जो नए sellers को Meesho पर professional seller account बनाकर देती है. Hum A-to-Z support देते हैं – account opening, product listing, orders, packing, dispatch aur RTO control tak.
          </p>
        </div>
      </div>
    </section>
  );
}
