export default function Footer() {
  return (
    <footer className="bg-purple-900 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <p className="text-purple-200">
            © Fortunemakers – Grow Online Business | Meesho Seller Account Setup & A-to-Z Management Service
          </p>
        </div>
      </div>
    </footer>
  );
}
